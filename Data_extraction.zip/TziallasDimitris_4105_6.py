import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from statistics import mean
from sklearn import metrics
from sklearn.metrics import classification_report, confusion_matrix, precision_score



data='diabetes.csv'


names=['Pregnancies','Glucose','BloodPressure','SkinThickness','Insulin','BMI','Diabetes','Age','Outcome']
dataset=pd.read_csv(data,names = names)

save=dataset.loc[:,['Pregnancies','Outcome']]

#Προεπεξεργασια Δεδομένων(Αλλαγη μηδενικων με τομ μεσο ορο καθε στηλης εκτος απο Outcome και Pregnancies)

colscheck=dataset.loc[:,['Glucose','BloodPressure','SkinThickness','Insulin','BMI','Diabetes','Age']]

colscheck=colscheck.replace(0,colscheck.mean(axis=0))
print(colscheck)

diabetes1=pd.concat([colscheck,save],axis=1,sort=True)
print(diabetes1)


diabetes1.to_csv('diabetes_missing_values_replace.csv')



#Taξινόμηση με ΚΝΝ classifier για το Dataset diabetes_missing_values_replace με κ=5
x1 = diabetes1.drop('Outcome', axis=1)
y1 = diabetes1['Outcome']
k = 5

for i in range(10):
    x_train, x_test, y_train, y_test = train_test_split(x1, y1, test_size=0.20)
    knn = KNeighborsClassifier(n_neighbors=k, metric='minkowski')
    knn.fit(x_train, y_train)
    y_pred = knn.predict(x_test)
    print(confusion_matrix(y_test,y_pred))
    print(classification_report(y_test, y_pred))
print('###########################################')
#Taξινόμηση με ΚΝΝ classifier για το Dataset diabetes_missing_values_replace με κ=1-15
x2 = diabetes1.drop('Outcome', axis=1)
y2 = diabetes1['Outcome']
k_range = range(1,16)
AccuracyAtest={}
AccuracyA=[]

for i in range(0,10):
    for k in k_range:
        x_train, x_test, y_train, y_test = train_test_split(x2, y2, test_size=0.20)
        knn = KNeighborsClassifier(n_neighbors=k, metric='minkowski')
        knn.fit(x_train, y_train)
        y_pred = knn.predict(x_test)
        AccuracyAtest[k]=metrics.accuracy_score(y_test,y_pred)
        AccuracyA.append(metrics.accuracy_score(y_test,y_pred))
        print(confusion_matrix(y_test,y_pred))
        print(classification_report(y_test, y_pred))
print('###########################################')
#Ταξινόμηση με KNN Classifier στο Dataset final_dataset με κ=5
     
final_dataset='final_dataset.csv' 
names=['Pregnancies','Glucose','BloodPressure','SkinThickness','Insulin','BMI','Diabetes','Age','Outcome']
diabetes2=pd.read_csv(data,names = names)
   
    
x3 = diabetes2.drop('Outcome', axis=1)
y3 = diabetes2['Outcome']
k = 5

for i in range(10):
    x_train, x_test, y_train, y_test = train_test_split(x1, y1, test_size=0.20)
    knn = KNeighborsClassifier(n_neighbors=k, metric='minkowski')
    knn.fit(x_train, y_train)
    y_pred = knn.predict(x_test)
    print(confusion_matrix(y_test,y_pred))
    print(classification_report(y_test, y_pred))   
print('###############################################')
#Ταξινόμηση με KNN Classifier στο Dataset final_dataset με κ=1-16

x2 = diabetes2.drop('Outcome', axis=1)
y2 = diabetes2['Outcome']
k_range = range(1,16)
AccuracyBtest={}
AccuracyB=[]

for i in range(0,10):
    for k in k_range:
        x_train, x_test, y_train, y_test = train_test_split(x2, y2, test_size=0.20)
        knn = KNeighborsClassifier(n_neighbors=k, metric='minkowski')
        knn.fit(x_train, y_train)
        y_pred = knn.predict(x_test)
        AccuracyBtest[k]=metrics.accuracy_score(y_test,y_pred)
        AccuracyB.append(metrics.accuracy_score(y_test,y_pred))
        print(confusion_matrix(y_test,y_pred))
        print(classification_report(y_test, y_pred))


        
AccuracyA_array=np.asarray(AccuracyA)
AccuracyB_array=np.asarray(AccuracyB)


#Accuracy A ,Accuracy mean value,min value and max value
print('AccuracyA:',AccuracyA)
print('AccuracyA mean value:',AccuracyA_array.mean())
print('AccuracyA min value:',AccuracyA_array.min())
print('AccuracyA max value:',AccuracyA_array.max())

#AccuracyB,AccuracyB mean value,min value and max value
print('AccuracyB:',AccuracyB)
print('AccuracyB mean value:',AccuracyB_array.mean())
print('AccuracyB min value:',AccuracyB_array.min())
print('AccuracyB max value:',AccuracyB_array.max())
