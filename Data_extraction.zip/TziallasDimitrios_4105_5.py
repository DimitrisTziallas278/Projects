import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import preprocessing 
from statistics import mean
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, precision_score,recall_score


data='breast-cancer-wisconsin.csv'

names=['ID Number','Clump Thickness','Uniformity_of_Cell_Size','Uniformity_of_Cell_Shape','Marginal Adhesion','Single Epithelial Cell Size','Bare Nuclei','Bland Chromatin','Normal Nucleoll','Mitoses','Class']
dataset=pd.read_csv(data,names = names)


#Preprocessing(Θα βγαλουμε τις γραμμες που περιεχουν ερωτηματικα)

save=dataset.loc[:,['ID Number','Clump Thickness','Uniformity_of_Cell_Size','Uniformity_of_Cell_Shape','Marginal Adhesion','Single Epithelial Cell Size','Bland Chromatin','Normal Nucleoll','Mitoses','Class']]

print(dataset)
print('#############################################')
print(len(dataset))

cols_to_check=dataset.loc[:,['Clump Thickness','Uniformity_of_Cell_Size','Uniformity_of_Cell_Shape','Marginal Adhesion','Single Epithelial Cell Size','Bare Nuclei']]

print('#############################################')
print(cols_to_check)


print('#############################################')
cols_to_check=cols_to_check.loc[~(cols_to_check=='?').any(axis=1)]


print('#############################################')
print(cols_to_check)
print(len(cols_to_check))

print('#############################################')
   
breast_cancer_wisconsin_2=pd.concat([cols_to_check,save],axis=1,sort=True)
print(breast_cancer_wisconsin_2)
print(len(breast_cancer_wisconsin_2))

breast_cancer_wisconsin_2=breast_cancer_wisconsin_2.dropna(how='any',axis=0)

print(breast_cancer_wisconsin_2)
print(len(breast_cancer_wisconsin_2))


#Κατηγοριοποιηση Δεδομενων και Training(Με χρηση του SVM classifier)

X=breast_cancer_wisconsin_2.drop(['ID Number','Class'],axis=1)
Y=breast_cancer_wisconsin_2['Class']


for i in range(0,10):
    #split to train and test data
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.10)
    svclassifier = SVC(kernel='linear')
    svclassifier.fit(X_train, Y_train)
    Y_pred = svclassifier.predict(X_test)
    print(confusion_matrix(Y_test,Y_pred))
    print(classification_report(Y_test,Y_pred))

