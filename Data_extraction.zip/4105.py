import pandas as pd
import numpy as np 
from sklearn import preprocessing

data='diabetes.csv'

names=['Pregnancies','Glucose','BloodPressure','SkinThickness','Insulin','BMI','DPF','Age','Outcome']
dataset=pd.read_csv(data,names = names)

#1ο ερώτημα
save=dataset.loc[:,['Pregnancies','Outcome']]

print(dataset)
print('#############################################')
print(len(dataset))

data1=dataset.loc[:,['Glucose','BloodPressure','SkinThickness','Insulin','BMI','DPF','Age']]
print('#############################################')
print(data1)
print('#############################################')
data1=data1.loc[~(data1==0).any(axis=1)]
print('#############################################')
print(data1)
print(len(data1))
print('#############################################')
final_dataset1=pd.concat([data1,save],axis=1,sort=True)
print(final_dataset1)
print(len(final_dataset1))






#2ο ερώτημα

threshold=40
print("################################")
      
print((dataset == 0).sum(axis=0))

data2=dataset.loc[:,['Glucose','BloodPressure','SkinThickness','Insulin','BMI','DPF','Age']]
print(data2)

drop_cols = data2.columns[(data2 == 0).sum() > threshold]
data2.drop(drop_cols, axis = 1, inplace = True) 

print('##########################################')

print(data2)


final_dataset=pd.concat([data2,save],axis=1,sort=True)
print(final_dataset)

final_dataset.to_csv('final_dataset.csv')
class1=0
class2=0
for i in range(len(final_dataset)):
    if final_dataset['Outcome'][i]==0:
        class1+= 1
        
    else :
        class2+= 1
    
print("People diagnosed with diabetes:{}\n".format(class1))
print("People that diagnosed without diabetes:{}\n".format(class2))