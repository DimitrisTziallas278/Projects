import pygame as pg
from settings import *
vec = pg.math.Vector2

class Player(pg.sprite.Sprite):
    def __init__(self, game,name):
        pg.sprite.Sprite.__init__(self)
        self.game = game
        self.image=pg.image.load(name)
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH / 2, HEIGHT / 2)
        self.pos = vec(WIDTH / 2, HEIGHT / 2)
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        self.jump_sound = pg.mixer.Sound('jump.wav')

    def jump(self):
        # jump only if standing on a platform
        self.rect.x += 1
        hits = pg.sprite.spritecollide(self, self.game.platforms, False)
        self.rect.x -= 1
        if hits:
            self.vel.y = -20
            self.jump_sound.play()
            self.jump_sound.set_volume(0.2)

    def update(self):
        self.acc = vec(0, PLAYER_GRAV)
        keys = pg.key.get_pressed()
        if keys[pg.K_LEFT]:
            self.acc.x = -PLAYER_ACC
        if keys[pg.K_RIGHT]:
            self.acc.x = PLAYER_ACC

        # apply friction
        self.acc.x += self.vel.x * PLAYER_FRICTION
        # equations of motion
        self.vel += self.acc
        self.pos += self.vel + 0.5 * self.acc
        self.rect.midbottom = self.pos

class Platform(pg.sprite.Sprite):
    def __init__(self, x, y,name,id):
        pg.sprite.Sprite.__init__(self)
        self.image=pg.image.load(name)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.id=id
    def get_id(self):
        return self.id
    def set_id(self,id):
        self.id=id


class Enemies(pg.sprite.Sprite):
    def __init__(self,x,y,name):
        pg.sprite.Sprite.__init__(self)
        self.image=pg.image.load(name)
        self.image.set_colorkey(BLACK)
        self.rect=self.image.get_rect()
        self.rect.x = x
        self .rect.y=y

    def movement(self,change):
        self.rect.x -= change


class Bullet(pg.sprite.Sprite):
    def __init__(self,x,y,name):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.image.load(name)
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        self.rect.x += 10

class Items(pg.sprite.Sprite):
    def __init__(self,x,y,name):
        pg.sprite.Sprite.__init__(self)
        self.image=pg.image.load(name)
        self.image.set_colorkey(BLACK)
        self.rect=self.image.get_rect()
        self.rect.x = x
        self .rect.y=y

    def movement(self,change):
        self.rect.x -= change

