import pygame as pg
import random
from settings import *
from Sprites import *

class Game:
    def __init__(self):
        # initialize game window, etc
        pg.init()
        pg.mixer.pre_init(44100, -16, 1, 512)
        pg.mixer.init()
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()
        self.running = True
        self.fireball_sound=pg.mixer.Sound('shoot.wav')
        self.damage_sound=pg.mixer.Sound('damage.wav')
        self.oof=pg.mixer.Sound('oof.wav')
        self.coin_sound=pg.mixer.Sound('coin.wav')
        self.Game_over=pg.mixer.Sound('Laugh.wav')
        self.Background_music=pg.mixer.Sound('Wonderboy.wav')
        self.start_screen_music=pg.mixer.Sound('Start.wav')
        self.health = 5
        self.heart = pg.image.load('heart.png')




    def new(self):
        # start a new game
        self.Game_over.stop()
        self.Background_music.play(loops=-1)
        self.Background_music.set_volume(0.3)

        self.score=0

        #Groups
        self.all_sprites = pg.sprite.Group()
        self.platforms = pg.sprite.Group()
        self.enemies= pg.sprite.Group()
        self.bullets=pg.sprite.Group()
        self.players=pg.sprite.Group()
        self.items = pg.sprite.Group()



        self.player = Player(self, 'Hero.png')
        self.players.add(self.player)
        self.all_sprites.add(self.player)

        for plat in PLATFORM_LIST:
            p = Platform(*plat)
            self.all_sprites.add(p)
            self.platforms.add(p)
        self.run()

    def run(self):
        # Game Loop
        self.playing = True
        while self.playing:
            self.clock.tick(FPS)
            self.events()
            self.update()
            self.draw()

    def update(self):
        # Game Loop - Update



        self.all_sprites.update()
        self.bullets.update()
        self.items.update()



        # check if player shoots or touches an enemy

        for enemy in self.enemies:
            if pg.sprite.spritecollide(enemy,self.bullets,False):
                self.damage_sound.play()
                self.damage_sound.set_volume(0.5)
                self.enemies.remove(enemy)
                self.all_sprites.remove(enemy)
                hit_list=pg.sprite.spritecollide(enemy,self.bullets,False)
                for bullet in hit_list:
                    self.bullets.remove(bullet)
                    self.score+=50
            elif pg.sprite.spritecollide(enemy,self.players,False):
                self.oof.play()
                self.damage_sound.set_volume(0.5)
                self.enemies.remove(enemy)
                self.all_sprites.remove(enemy)
                self.health -=1
                if self.health == 0:
                    self.playing=False
                    return

        #check if player picks up an item
        for item in self.items:
            if pg.sprite.spritecollide(item,self.players,False):
                self.coin_sound.play()
                self.coin_sound.set_volume(0.5)
                self.items.remove(item)
                self.all_sprites.remove(item)
                self.score +=100


        # check if player hits a platform - only if falling
        if self.player.vel.y > 0:
            hits = pg.sprite.spritecollide(self.player, self.platforms, False)
            if hits:
                self.player.pos.y = hits[0].rect.top
                self.player.vel.y = 0





        # if player reaches left side of the screen

        if self.player.rect.left >= WIDTH / 3:
            if self.player.vel.x > 0:
                for enemy in self.enemies:
                    enemy.movement(abs(self.player.vel.x))
                for item in self.items:
                    item.movement(abs(self.player.vel.x))

            self.player.pos.x -= abs(self.player.vel.x)
            for plat in self.platforms:
                plat.rect.x -= abs(self.player.vel.x)

                if plat.get_id() == 2 and plat.rect.x <= -500:
                    self.platforms.remove(plat)
                    self.all_sprites.remove(plat)
                    self.score+=10
                elif plat.get_id()==1 and plat.rect.x<=- WIDTH:

                    self.platforms.remove(plat)
                    self.all_sprites.remove(plat)
                    self.score+=10

                elif plat.get_id()==0 and plat.rect.x<0:
                    plat.set_id(1)
                    print(BASE)
                    x=BASE[0]+WIDTH
                    print(x)
                    p=Platform(x,BASE[1],'base_platform.png',0)
                    self.platforms.add(p)
                    self.all_sprites.add(p)

            for enemy in self.enemies:
                if enemy.rect.x <= -200 :
                    self.enemies.remove(enemy)
                    self.all_sprites.remove(enemy)

            for item in self.items:
                if item.rect.x <= -200 :
                    self.items.remove(item)
                    self.all_sprites.remove(item)



            for bullet in self.bullets:
                if bullet.rect.x >1000:
                    self.bullets.remove(bullet)
                    self.all_sprites.remove(bullet)


        # spawn new platforms,enemies,items to keep same average number



        while len(self.platforms) < 3:
            width = random.randrange(50,100)
            p = Platform(random.randrange(WIDTH, WIDTH + width),500, 'Platform.png',2)
            self.platforms.add(p)
            self.all_sprites.add(p)


        while len(self.enemies) < 1:
            enemy= Enemies(random.randrange(700,1000),620,'enemy.png')
            self.enemies.add(enemy)
            self.all_sprites.add(enemy)


        while len(self.items) < 1:

            r=random.randrange(350,700-(600-450))
            if r>500:
                y=r+150
            else:
                y=r
            item=Items(random.randrange(700,1000),y,'coin.png')
            self.items.add(item)
            self.items.add(item)









    def events(self):
        # Game Loop - events
        for event in pg.event.get():
            # check for closing window
            if event.type == pg.QUIT:
                if self.playing:
                    self.playing = False
                self.running = False
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_SPACE:
                    self.player.jump()

                if event.key == pg.K_s:
                    self.fireball_sound.play()
                    self.fireball_sound.set_volume(0.4)
                    bullet=Bullet(self.player.rect.x,self.player.rect.y,'Bullet.png')
                    self.bullets.add(bullet)

    def draw(self):
        # Game Loop - draw
        self.screen.fill(LIGHT_BLUE)
        self.all_sprites.draw(self.screen)
        self.bullets.draw(self.screen)
        self.items.draw(self.screen)

        self.draw_text(str(self.score),50,BLACK,WIDTH/2,30)

        for i in range(self.health):  # draw red health bars
            self.screen.blit(self.heart, [100 + (i * 30), 30])





        #  drawing everything, flip the display
        pg.display.flip()
    #Start screen
    def show_start_screen(self):
        bg=pg.image.load('start_screen.png')
        self.start_screen_music.play(loops=-1)
        self.start_screen_music.set_volume(0.2)
        self.screen.blit(bg,[150,100])
        self.draw_text('INSTRUCTIONS', 30, RED, WIDTH / 2, 300)
        self.draw_text('Arrows to move,Space to Jump,S key to shoot', 30, RED, WIDTH / 2, 350)
        self.draw_text('Press any key', 30, RED, WIDTH / 2, 500)
        self.draw_text('Made by Dimitris Tziallas',30,RED,WIDTH/2,600)
        self.draw_text('AM:4105',30,RED,WIDTH/2,630)
        pg.display.flip()
        self.wait()




    #Game over screen
    def show_game_over_screen(self):
        if self.running==True:
            self.Background_music.stop()
            self.Game_over.play()
            self.Game_over.set_volume(0.5)
            self.screen.fill(BLACK)
            bg=pg.image.load('game_over.png')
            self.screen.blit(bg, [175, 100])
            self.draw_text('You scored:'+ str(self.score),30,RED,WIDTH/2,350)
            self.draw_text('Press any key to play again',30,RED,WIDTH/2,500)
            self.health=5
            pg.display.flip()
            self.wait_2()



    def wait(self):
        waiting=True
        self.clock.tick(30)
        while waiting:
            for event in pg.event.get():
                if event.type==pg.QUIT:
                    waiting=False
                    self.running = False
                if event.type ==pg.KEYUP:
                    waiting=False
                    self.start_screen_music.stop()

    def wait_2(self):
        waiting =True
        self.clock.tick(30)
        while waiting:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting=False
                    self.running=False
                if event.type == pg.KEYDOWN:
                    waiting=False



    def draw_text(self,text,size,color,x,y):
        font = pg.font.Font('Pixel.otf', 20)
        text_surface=font.render(text,True,color)
        text_rect=text_surface.get_rect()
        text_rect.midtop=(x,y)
        self.screen.blit(text_surface,text_rect)


g = Game()
g.show_start_screen()

while g.running:
    g.new()
    g.show_game_over_screen()

pg.quit()