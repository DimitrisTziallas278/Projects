import numpy as np 
import matplotlib.pyplot as plt

#Πρωτο ερώτημα

dataset=np.loadtxt('first_attempt_dataset.txt')
print(dataset)

class1=np.empty((0,2),dtype='float')
class2=np.empty((0,2),dtype='float')


for i in range(len(dataset)):
    if dataset[i][2]==1:
        class1=np.append(class1,[dataset[i][0],dataset[i][1]])
        
    if dataset[i][2]==2:
        class2=np.append(class2,[dataset[i][0],dataset[i][1]])
        
class1=np.reshape(class1,(int(len(class1)/2),2))

class2=np.reshape(class2,(int(len(class2)/2),2))

print("Class1:\n")
print(class1)
print("Class2:\n")
print(class2)

#Ερώτημα 2ο
for i in range(len(class1)):
    plt.plot(class1[i][0],class1[i][1],"o",color="black")



for i in range(len(class2)):
    plt.plot(class2[i][0],class2[i][1],"o",color="red")
    
plt.show()    