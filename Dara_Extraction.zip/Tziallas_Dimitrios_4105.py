
import numpy as np
import matplotlib as plt

a=np.array[(a,b,c)]
print(a)