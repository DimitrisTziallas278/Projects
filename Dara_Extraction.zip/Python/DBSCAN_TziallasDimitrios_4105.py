import numpy as np
import matplotlib.pyplot as plt
from sklearn import cluster, datasets
from sklearn.preprocessing import StandardScaler
from itertools import cycle, islice
from sklearn.cluster import DBSCAN 




n_samples = 1500
random_state = 170

np.random.seed(0)
#make and plot circles 
noisy_circles_x,noisy_circles_y = datasets.make_circles(n_samples=n_samples, factor=.5,noise=.05)



#make and plot moons
noisy_moons_x,noisy_moons_y = datasets.make_moons(n_samples=n_samples, noise=.05)


#make and plot blobs
blobs_x,blobs_y = datasets.make_blobs(n_samples=n_samples, random_state=8)


#make and plot no structure 
no_structure_x,no_structure_y = np.random.rand(n_samples, 2), None


# blobs with varied variances
varied_x,varied_y = datasets.make_blobs(n_samples=n_samples,cluster_std=[1.0, 2.5, 0.5],random_state=random_state)


# Anisotropicly distributed data
random_state = 170
X, y = datasets.make_blobs(n_samples=n_samples,random_state = random_state)
transformation = [[0.6, -0.6], [-0.4, 0.8]]
X_aniso = np.dot(X, transformation)
aniso = (X_aniso, y)



#1

plt.figure(figsize=(10,7))

plt.scatter(noisy_circles_x[:,0],noisy_circles_x[:,1], s=70, c='black')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Noisy Circles')

plt.legend()
plt.show()

xx = DBSCAN(eps = 0.15, min_samples=9 , metric='euclidean').fit(noisy_circles_x)

plt.figure(figsize=(10,7))


plt.scatter(noisy_circles_x[xx.labels_ == 0,0],noisy_circles_x[xx.labels_ == 0,1], s=70, c='red', label='cluster1')
plt.scatter(noisy_circles_x[xx.labels_ == 1,0],noisy_circles_x[xx.labels_ == 1,1], s=70, c='green', label='cluster2')
plt.scatter(noisy_circles_x[xx.labels_ == -1,0],noisy_circles_x[xx.labels_ == -1,1], s=70, c='pink', label='outliers')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Noisy Circles')

plt.legend()
plt.show()

#2

plt.figure(figsize=(10,7))

plt.scatter(noisy_moons_x[:,0],noisy_moons_x[:,1], s=70, c='black')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Noisy Moons')

plt.legend()
plt.show()

xx = DBSCAN(eps = 0.15, min_samples=9 , metric='euclidean').fit(noisy_moons_x)

plt.figure(figsize=(10,7))


plt.scatter(noisy_moons_x[xx.labels_ == 0,0],noisy_moons_x[xx.labels_ == 0,1], s=70, c='red', label='cluster1')
plt.scatter(noisy_moons_x[xx.labels_ == 1,0],noisy_moons_x[xx.labels_ == 1,1], s=70, c='green', label='cluster2')
plt.scatter(noisy_moons_x[xx.labels_ == -1,0],noisy_moons_x[xx.labels_ == -1,1], s=70, c='pink', label='outliers')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Noisy Moons')
plt.legend()
plt.show()

#3

plt.figure(figsize=(10,7))

plt.scatter(blobs_x[:,0],blobs_x[:,1], s=70, c='black')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Blobs')

plt.legend()
plt.show()

xx = DBSCAN(eps = 0.8, min_samples=9 , metric='euclidean').fit(blobs_x)

plt.figure(figsize=(10,7))


plt.scatter(blobs_x[xx.labels_ == 0,0],blobs_x[xx.labels_ == 0,1], s=70, c='red', label='cluster1')
plt.scatter(blobs_x[xx.labels_ == 1,0],blobs_x[xx.labels_ == 1,1], s=70, c='green', label='cluster2')
plt.scatter(blobs_x[xx.labels_ == 2,0],blobs_x[xx.labels_ == 2,1], s=70, c='orange', label='cluster3')
plt.scatter(blobs_x[xx.labels_ == -1,0],blobs_x[xx.labels_ == -1,1], s=70, c='pink', label='outliers')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Blobs')
plt.legend()
plt.show()

#4
plt.figure(figsize=(10,7))

plt.scatter(no_structure_x[:,0],no_structure_x[:,1], s=70, c='black')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('No Structure')
plt.legend()
plt.show()

xx = DBSCAN(eps = 0.1, min_samples=7 , metric='euclidean').fit(no_structure_x)

plt.figure(figsize=(10,7))


plt.scatter(no_structure_x[xx.labels_ == 0,0],no_structure_x[xx.labels_ == 0,1], s=70, c='red', label='cluster1')
plt.scatter(no_structure_x[xx.labels_ == 1,0],no_structure_x[xx.labels_ == 1,1], s=70, c='green', label='cluster2')
plt.scatter(no_structure_x[xx.labels_ == -1,0],no_structure_x[xx.labels_ == -1,1], s=70, c='pink', label='outliers')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('No Structure')
plt.legend()
plt.show()

#5

plt.figure(figsize=(10,7))

plt.scatter(varied_x[:,0],varied_x[:,1], s=70, c='black')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Varied')
plt.legend()
plt.show()

xx = DBSCAN(eps = 0.75, min_samples=8 , metric='euclidean').fit(varied_x)

plt.figure(figsize=(10,7))


plt.scatter(varied_x[xx.labels_ == 0,0],varied_x[xx.labels_ == 0,1], s=70, c='red', label='cluster1')
plt.scatter(varied_x[xx.labels_ == 1,0],varied_x[xx.labels_ == 1,1], s=70, c='green', label='cluster2')
plt.scatter(varied_x[xx.labels_ == 2,0],varied_x[xx.labels_ == 2,1], s=70, c='orange',label='cluster3')
plt.scatter(varied_x[xx.labels_ == -1,0],varied_x[xx.labels_ == -1,1], s=70, c='pink', label='outliers')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Varied')
plt.legend()
plt.show()

#6

plt.figure(figsize=(10,7))

plt.scatter(X_aniso[:,0],X_aniso[:,1], s=70, c='black')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Aniso')
plt.legend()
plt.show()

xx = DBSCAN(eps = 0.35, min_samples=5, metric='euclidean').fit(X_aniso)

plt.figure(figsize=(10,7))


plt.scatter(X_aniso[xx.labels_ == 0,0],X_aniso[xx.labels_ == 0,1], s=70, c='red', label='cluster1')
plt.scatter(X_aniso[xx.labels_ == 1,0],X_aniso[xx.labels_ == 1,1], s=70, c='green', label='cluster2')
plt.scatter(X_aniso[xx.labels_ == 2,0],X_aniso[xx.labels_ == 2,1], s=70, c='orange',label='cluster3')
plt.scatter(X_aniso[xx.labels_ == -1,0],X_aniso[xx.labels_ == -1,1], s=70, c='pink', label='outliers')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Aniso')
plt.legend()
plt.show()