import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
from sklearn import cluster, datasets
import scipy.cluster.hierarchy as shc
from sklearn.cluster import AgglomerativeClustering
from sklearn.preprocessing import StandardScaler
from itertools import cycle, islice


n_samples = 1500
random_state = 170

np.random.seed(0)
#make and plot circles 
noisy_circles_x,noisy_circles_y = datasets.make_circles(n_samples=n_samples, factor=.5,noise=.05)



#make and plot moons
noisy_moons_x,noisy_moons_y = datasets.make_moons(n_samples=n_samples, noise=.05)


#make and plot blobs
blobs_x,blobs_y = datasets.make_blobs(n_samples=n_samples, random_state=8)


#make and plot no structure 
no_structure_x,no_structure_y = np.random.rand(n_samples, 2), None


# blobs with varied variances
varied_x,varied_y = datasets.make_blobs(n_samples=n_samples,cluster_std=[1.0, 2.5, 0.5],random_state=random_state)


# Anisotropicly distributed data
random_state = 170
X, y = datasets.make_blobs(n_samples=n_samples,random_state = random_state)
transformation = [[0.6, -0.6], [-0.4, 0.8]]
X_aniso = np.dot(X, transformation)
aniso = (X_aniso, y)


#1
plt.scatter(noisy_circles_x[:,0],noisy_circles_x[:,1],s=100,c='black',label ='Circles')
plt.legend()
plt.show()

plt.figure(figsize=(10,7))

cluster1=AgglomerativeClustering(n_clusters=3,affinity='euclidean',linkage='single')
xx=cluster1.fit_predict(noisy_circles_x)

plt.figure(figsize=(10,7))

plt.scatter(noisy_circles_x[xx==0,0],noisy_circles_x[xx==0,1],c='red',label='cluster1')
plt.scatter(noisy_circles_x[xx==1,0],noisy_circles_x[xx==1,1],c='green',label='cluster2')
plt.legend()
plt.show()



#2
x1=noisy_moons_x
y1=noisy_moons_y

plt.scatter(x1[:,0],x1[:,1],s=100,c='black',label ='Moons')
plt.legend()
plt.show()

plt.figure(figsize=(10,7))

cluster2=AgglomerativeClustering(n_clusters=2,affinity='euclidean',linkage='single')
xx=cluster2.fit_predict(x1)

plt.figure(figsize=(10,7))

plt.scatter(x1[xx==0,0],x1[xx==0,1],c='red',label='cluster1')
plt.scatter(x1[xx==1,0],x1[xx==1,1],c='green',label='cluster2')
plt.legend()
plt.show()


#3
plt.scatter(blobs_x[:,0],blobs_x[:,1],s=100,c='black',label ='Blobs')
plt.legend()
plt.show()

plt.figure(figsize=(10,7))


cluster3=AgglomerativeClustering(n_clusters=2,affinity='euclidean',linkage='ward')
xx=cluster1.fit_predict(blobs_x)

plt.figure(figsize=(10,7))
plt.scatter(blobs_x[xx==0,0],blobs_x[xx==0,1],c='red',label='cluster1')
plt.scatter(blobs_x[xx==1,0],blobs_x[xx==1,1],c='green',label='cluster2')
plt.scatter(blobs_x[xx==2,0],blobs_x[xx==2,1],c='orange',label='cluster3')
plt.legend()
plt.show()


#4
plt.scatter(no_structure_x[:,0],no_structure_x[:,1],s=100,c='black',label ='No structure')
plt.legend()
plt.show()

plt.figure(figsize=(10,7))

cluster4=AgglomerativeClustering(n_clusters=3,affinity='euclidean',linkage='ward')
xx=cluster4.fit_predict(no_structure_x)

plt.figure(figsize=(10,7))

plt.scatter(no_structure_x[xx==0,0],no_structure_x[xx==0,1],c='red',label='cluster1')
plt.scatter(no_structure_x[xx==1,0],no_structure_x[xx==1,1],c='green',label='cluster2')
plt.legend()
plt.show()

#5
plt.scatter(varied_x[:,0],varied_x[:,1],s=100,c='black',label ='Varied')
plt.legend()
plt.show()

plt.figure(figsize=(10,7))
cluster1=AgglomerativeClustering(n_clusters=3,affinity='euclidean',linkage='ward')
xx=cluster1.fit_predict(varied_x)

plt.figure(figsize=(10,7))

plt.scatter(varied_x[xx==0,0],varied_x[xx==0,1],c='red',label='cluster1')
plt.scatter(varied_x[xx==1,0],varied_x[xx==1,1],c='green',label='cluster2')
plt.scatter(varied_x[xx==2,0],varied_x[xx==2,1],c='orange',label='cluster3')
plt.legend()
plt.show()


#6
plt.scatter(X_aniso[:,0],X_aniso[:,1],s=100,c='black',label ='Aniso')
plt.legend()
plt.show()

plt.figure(figsize=(10,7))
cluster1=AgglomerativeClustering(n_clusters=3,affinity='euclidean',linkage='ward')
xx=cluster1.fit_predict(X_aniso)

plt.figure(figsize=(10,7))

plt.scatter(X_aniso[xx==0,0],X_aniso[xx==0,1],c='red',label='cluster1')
plt.scatter(X_aniso[xx==1,0],X_aniso[xx==1,1],c='green',label='cluster2')
plt.scatter(X_aniso[xx==2,0],X_aniso[xx==2,1],c='orange',label='cluster3')
plt.legend()
plt.show()

